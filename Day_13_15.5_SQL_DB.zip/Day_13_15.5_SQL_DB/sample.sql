DROP DATABASE IF EXISTS sample;
CREATE DATABASE sample;
use sample;
DROP TABLE IF EXISTS Student;
CREATE TABLE Student(
   student_id INT NOT NULL AUTO_INCREMENT, 
   name VARCHAR(100), 
   age INT,
   PRIMARY KEY (student_id)
   );
INSERT INTO Student(name, age) VALUES('Adam', 15),
('Sarah', 16), ('Bob', 25),
('Alice', 18), ('Biff', 47);